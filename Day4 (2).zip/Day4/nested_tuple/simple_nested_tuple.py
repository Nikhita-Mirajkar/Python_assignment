# 1.
# x = ("Boss", [8, 4, 6], (1, 2, 3))
# print(x)


# 2.
# x = ((2, "w"), (3, "r"))
# result = {value: key for key, value in x}
# print(result)


# 3.
# x = (1, [9, 8, 7], "boss")
# x[1][2] = 77  # Modifying the list inside the tuple
# print(x)


# 4.
# L = ("a", ("b", "c"), "d", ("e", "f"))
# print(L)
# print(len(L))

# 5.
# t1 = (1, 2)
# t2 = ('a', 'b')
# t3 = ('A', 'B')
#
# nested_tuple = (t3[0], t1, t3[1], t2)
# print("Create/print nested tuple:")
# print(nested_tuple)
# print("Length of nested tuple is:")
# print(len(nested_tuple))


# 6.
# t1 = ("a",)
# t2 = (t1 * 2)  # => ('a', 'a')
# print(t2)
# print("Contains", t2[0])


# 7.
# def count_nested_tuple(t):
#     count = 0
#     for item in t:
#         if isinstance(item, tuple):
#             count += count_nested_tuple(item)
#         else:
#             count += 1
#     return count
#
# t1 = (1, (4, (7, 8, 9), 6), 3)
# print(count_nested_tuple(t1))


# 8.
# t = ((4, 'Sara'), (3, 'Shar'), (6, 'Sid'))
# result = [{'key': k, 'value': v} for k, v in t]
# print("The original tuple :", t)
# print("The converted dictionary :", result)


# 9.
# l = [('Sara', 1), ('Shar', 2), ('Sid', 3), ('Shwe', 4)]
# print("Original list is :", l)
#
# names, numbers = zip(*l)
# print("Modified list is :", [list(names), list(numbers)])


10.
data = ((10, 20, 40), (40, 50, 60), (70, 80, 90))
modified = [t[:-1] + (100,) for t in data]
print(modified)

