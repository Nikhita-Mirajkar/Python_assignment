# 1.
# from itertools import chain
#
# data = [0, 10, [20, 30], 40, 50, [60, 70, 80], [90, 100, 110, 120]]
# flattened = list(chain.from_iterable(i if isinstance(i, list) else [i] for i in data))
# print(flattened)
from itertools import groupby

# 2.
# from itertools import groupby
#
# data = [0, 0, 1, 2, 3, 4, 4, 5, 6, 6, 6, 7, 8, 9, 4, 4]
# packed = [list(group) for _, group in groupby(data)]
# print(packed)

# 3.
# from itertools import groupby
# def run_length_encode(seq):
#     return [[len(list(group)), key] for key, group in groupby(seq)]
#
# print(run_length_encode([1, 1, 2, 3, 4, 4.3, 5, 1]))
# print(run_length_encode("aidinasaur"))

# 4.
# from itertools import groupby
# def modified_rle(seq):
#     result = []
#     for key, group in groupby(seq):
#         group_list = list(group)
#         if len(group_list) > 1:
#             result.append([len(group_list), key])
#         else:
#             result.append(key)
#     return result
# print(modified_rle([1, 1, 2, 3, 4, 4, 5, 1]))
# print(modified_rle("aabcddddadnss"))

# 6.
# lst = [1, 1, 2, 3, 4, 4, 5, 1]
# n = 3
# first, second = lst[:n], lst[n:]
# print("Length of first part:", n)
# print("Split list:", (first, second))


# 7.
# lists1 = [[1, 3], [5, 7], [9, 11], [13, 15, 17]]
# lists2 = [[2, 4], [[6, 8], [4, 5, 8]], [10, 12, 14]]
#
# count1 = sum(1 for i in lists1 if isinstance(i, list))
# count2 = sum(1 for i in lists2 if isinstance(i, list))
#
# print(count1)
# print(count2)


# 8.
# def find_min_max(data):
#     max_list = max(data, key=len)
#     min_list = min(data, key=len)
#     return (len(max_list), max_list), (len(min_list), min_list)
#
# lists = [
#     [[0], [1, 3], [5, 7], [9, 11], [13, 15, 17]],
#     [[0], [1, 3], [5, 7], [9, 11], [3, 5, 7]],
#     [[12], [1, 3], [1, 34, 5, 7], [9, 11], [3, 5, 7]]
# ]
#
# for lst in lists:
#     print("Original list:", lst)
#     max_len, min_len = find_min_max(lst)
#     print("Max:", max_len)
#     print("Min:", min_len)

# 9.
# def count_occurrence(lst, val):
#     return sum(1 for sub in lst if val in sub)
#
# data1 = [[1, 3], [5, 7], [1, 11], [1, 15, 7]]
# print(count_occurrence(data1, 1))  # 3
# print(count_occurrence(data1, 7))  # 2
#
# data2 = [['A', 'B'], ['A', 'C'], ['A', 'D', 'E'], ['B', 'C', 'D']]
# print(count_occurrence(data2, 'A'))
# print(count_occurrence(data2, 'E'))
#
# 10.
# data = [[2], [0], [1, 2, 3], [0, 1, 2, 3, 6, 7], [9, 11], [13, 14, 15, 17]]
# min_val, max_val = 10, 20
#
# filtered = [sub for sub in data if all(min_val <= x <= max_val for x in sub)]
# print("Filtered list:", filtered)

11.
def remove_column(data, col_index):
    return [row[:col_index] + row[col_index+1:] for row in data]

nested1 = [[1, 2, 3], [2, 4, 5], [1, 1, 1]]
nested2 = [[1, 2, 3], [-2, 4, -5], [1, -1, 1]]

print(remove_column(nested1, 0))
print(remove_column(nested2, 2))

