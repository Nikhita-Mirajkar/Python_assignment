# 1.
# student = {'id1':
#    {'name': ['Boss'],
#     'class': ['V'],
#     'subject_integration': ['english, math, science']
#    },
#  'id2':
#   {'name': ['Siva'],
#     'class': ['V'],
#     'subject_integration': ['english, math, science']
#    },
#  'id3':
#     {'name': ['Boss'],
#     'class': ['V'],
#     'subject_integration': ['english, math, science']
#    },
#  'id4':
#    {'name': ['Surya'],
#     'class': ['V'],
#     'subject_integration': ['english, math, science']
#    },
# }
#
# def remove_duplicates(data):
#     seen = set()
#     result = {}
#     for k, v in data.items():
#         val_tuple = tuple(sorted((key, tuple(value) if isinstance(value, list) else value) for key, value in v.items()))
#         if val_tuple not in seen:
#             seen.add(val_tuple)
#             result[k] = v
#     return result
#
# print(remove_duplicates(student))



# 2.
# import json
# d = {'students': [{'firstName': 'Boss', 'lastName': 'Roysden'},
#                   {'firstName': 'Kumar', 'lastName': 'Friedland'},
#                   {'firstName': 'Arul ', 'lastName': 'Wilkins'}],
#      'teachers': [{'firstName': 'Suresh', 'lastName': 'Calico'},
#                   {'firstName': 'Dinesh', 'lastName': 'Agtarap'}]}
# with open('data.json', 'w') as f:
#     json.dump(d, f, indent=4)
# with open('data.json', 'r') as f:
#     data = json.load(f)
#
# print("Json file to dictionary:")
# print(data)



#3.
# D = {'id1':
#    {'name': ['Boss'],
#     'class': ['V'],
#     'subject_integration': ['english, math, science']
#    },
#  'id2':
#   {'name': ['Siva'],
#     'class': ['V'],
#     'subject_integration': ['english, math, science']
#    },
#  'id3':
#     {'name': ['Boss'],
#     'class': ['V'],
#     'subject_integration': ['english, math, science']
#    },
#  'id4':
#    {'name': ['Surya'],
#     'class': ['V'],
#     'subject_integration': ['english, math, science']
#    },
# }
#
# for emp_id, info in D.items():
#     print(f"Employee ID: {emp_id}")
#     for key, value in info.items():
#         print(f"{key}: {value}")
#     print()



# 4.
# D = [{'key': {'subkey': 1}}, {'key': {'subkey': 10}}, {'key': {'subkey': 5}}]
#
# # Sort descending order by subkey
# sorted_list = sorted(D, key=lambda x: x['key']['subkey'], reverse=True)
#
# print(sorted_list)


# 5.
# D = {'x': 1, 'y': {'z': 3, 'd': 4}}
#
# def flatten_dict(d):
#     flat = {}
#     for k, v in d.items():
#         if isinstance(v, dict):
#             for subk, subv in v.items():
#                 flat[subk] = subv
#         else:
#             flat[k] = v
#     return flat
#
# print(flatten_dict(D))

# 6.
# weapons = {
#     '': None,
#     'sword': {'steel': 1234, 'sharpness': 344, 'age': 24},
#     'arrow': {'steel': 1200, 'sharpness': 305, 'age': 12}
# }
#
# total_sharpness = 0
# for k, v in weapons.items():
#     if isinstance(v, dict) and 'sharpness' in v:
#         total_sharpness += v['sharpness']
#
# print(total_sharpness)

# 7.
# data = {'gfg': {'best': 4, 'good': 5}, 'is': {'better': 6, 'educational': 4}, 'CS': {'priceless': 6}}
#
# def remove_cs_values(d):
#     if 'CS' in d and isinstance(d['CS'], dict):
#         d['CS'].clear()
#
#     if 'is' in d and isinstance(d['is'], dict):
#         d['is'].pop('better', None)
#     return d
#
# print("Dictionary after removal :")
# print(remove_cs_values(data))


# 8.
# lst = [{'gfg': {'data': 1}}, {'is': {'data': 5}}, {'best': {'data': 4}}]
#
# result = {}
# for item in lst:
#     for k, v in item.items():
#         result[k] = v['data']
#
# print("The constructed Dictionary list :")
# print(result)


# 9.
# test_list1 = ["Boss", 'Siva', 'best']
# test_list2 = ['ratings', 'price', 'score']
# test_list3 = [5, 6, 7]
#
# print(f"The original list 1 is : {test_list1}")
# print(f"The original list 2 is : {test_list2}")
# print(f"The original list 3 is : {test_list3}")
#
# result = [{test_list1[i]: {test_list2[i]: test_list3[i]}} for i in range(len(test_list1))]
#
# print("The constructed dictionary :")
# print(result)


10.
data = {'gfg': {'x': 5, 'y': 6}, 'is': {'x': 1, 'y': 4}, 'best': {'x': 8, 'y': 3}}

# Extract the inner keys (assume all have the same keys)
inner_keys = list(next(iter(data.values())).keys())

# For each inner key, collect the values across all outer keys
grouped = [(key, tuple(data[outer][key] for outer in data)) for key in inner_keys]

print("The grouped dictionary :")
print(grouped)


