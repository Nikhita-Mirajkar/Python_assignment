# 1.
# nested_dict = {
#     'x': {'name': 'Boss', 'job': 'Mgr'},
#     'y': {'name': 'Suresh', 'job': 'Dev'},
#     'z': {'name': 'Siva', 'job': 'Dev'}
# }
# print(nested_dict)

# 2.
# IDs = ['x', 'y', 'z']
# EmpInfo = [{'name': 'Boss', 'job': 'Mgr'}, {'name': 'Suresh', 'job': 'Dev'}, {'name': 'Siva', 'job': 'Dev'}]
#
# nested_dict = dict(zip(IDs, EmpInfo))
# print(nested_dict)

# 3.
# IDs = ['x', 'y', 'z']
# Defaults = {'name': '', 'job': ''}
#
# nested_dict = dict.fromkeys(IDs, Defaults.copy())
# print(nested_dict)

# 4.
# D = {'x': {'name': 'Boss', 'job': 'Mgr'},
#      'y': {'name': 'Suresh', 'job': 'Dev'},
#      'z': {'name': 'Siva', 'job': 'Dev'}}
#
# print(D['x']['name'])
# print(D['y']['job'])

# 5.
# D = {'x': {'name': 'Boss', 'job': 'Mgr'},
#      'y': {'name': 'Suresh', 'job': 'Dev'},
#      'z': {'name': 'Siva', 'job': 'Dev'}}
#
# print(D.get('x', {}).get('name'))
# print(D.get('a', {}).get('name'))

# 6.
# D = {'x': {'name': 'Boss', 'job': 'Mgr'},
#      'y': {'name': 'Suresh', 'job': 'Dev'},
#      'z': {'name': 'Siva', 'job': 'Dev'}}
#
# D['z']['name'] = 'Karthi'
# D['z']['job'] = 'Janitor'
# print(D['z'])


# 7.
# D = {'x': {'name': 'Boss', 'job': 'Mgr'},
#      'y': {'name': 'Suresh', 'job': 'Dev'},
#      'z': {'name': 'Siva', 'job': 'Dev'}}
#
# D['z'].update({'name': 'Karthi', 'job': 'Janitor'})
# print(D)


# 8.
# D = {'x': {'name': 'Boss', 'job': 'Mgr'},
#      'y': {'name': 'Suresh', 'job': 'Dev'},
#      'z': {'name': 'Siva', 'job': 'Dev'}}
#
# D['A'] = {'name': 'Karthi', 'job': 'Janitor'}
# print(D)

# 9.
# D1 = {'x': {'name': 'Boss', 'job': 'Mgr'}, 'y': {'name': 'Suresh', 'job': 'Dev'}}
# D2 = {'z': {'name': 'Siva', 'job': 'Dev'}, 'A': {'name': 'Karthi', 'job': 'Janitor'}}
#
# D1.update(D2)
# print(D1)

10.
D = {'x': {'name': 'Boss', 'job': 'Mgr'},
     'y': {'name': 'Suresh', 'job': 'Dev'},
     'z': {'name': 'Siva', 'job': 'Dev'}}

removed = D.pop('z')
print(D)
print(removed)


