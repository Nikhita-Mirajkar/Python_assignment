# 1.
# D = {'x': {'name': 'Boss', 'job': 'Mgr'},
#      'y': {'name': 'Suresh', 'job': 'Dev'},
#      'z': {'name': 'Siva', 'job': 'Dev'}}
#
# for emp_id, info in D.items():
#     print(f"Employee ID: {emp_id}")
#     for key, value in info.items():
#         print(f"{key}: {value}")
#     print()

# 2.
# X = [1, 2, 3, 4]
#
# nested_dict = current = {}
# for key in X:
#     current[key] = {}
#     current = current[key]
#
# print(nested_dict)

# 3.
# from collections import Counter
#
# data = [{'item': 'item1', 'amount': 400},
#         {'item': 'item2', 'amount': 300},
#         {'item': 'item1', 'amount': 750}]
#
# counter = Counter()
# for d in data:
#     counter[d['item']] += d['amount']
#
# print(counter)
#
# 4.
# L = [{"V": "Boss"}, {"V": "Siva"}, {"VI": "Suresh"}, {"VI": "Dinesh"},
#      {"VII": "Karthi"}, {"V": "Kumar"}, {"VIII": "Sai"}]
#
# unique_values = {v for d in L for v in d.values()}
# print("Unique Values: ", unique_values)


# 5.
# students = {"Boss": {"class": "V", "rolld_id": 2},
#             "Suresh": {"class": "V", "rolld_id": 3}}
#
# for student, details in students.items():
#     print(student)
#     for key, value in details.items():
#         print(f"{key} : {value}")

6.
# people = {1: {'name': 'Suresh', 'age': '27', 'sex': 'Male'},
#           2: {'name': 'Siva', 'age': '22', 'sex': 'Female'},
#           3: {'name': 'Bala', 'age': '24', 'sex': 'Female', 'married': 'No'},
#           4: {'name': 'Karthi', 'age': '29', 'sex': 'Male', 'married': 'Yes'}}
#
# for key in [3, 4]:
#     people[key].pop('married', None)
#     print(people[key])


# 7.
# Dict = {'Dict1': {'name': 'Boss', 'age': '19'},
#         'Dict2': {'name': 'Karthi', 'age': '25'}}
#
# print(Dict['Dict1']['name'])
# print(Dict['Dict2']['age'])


# 8.
# def flatten_dict(d, parent_key='', sep='_'):
#     items = {}
#     for k, v in d.items():
#         new_key = parent_key + sep + k if parent_key else k
#         if isinstance(v, dict):
#             items.update(flatten_dict(v, new_key, sep=sep))
#         else:
#             items[new_key] = v
#     return items
#
# data = {'geeks': {'Geeks': {'for': 7}},
#         'for': {'geeks': {'Geeks': 3}},
#         'Geeks': {'for': {'for': 1, 'geeks': 4}}}
#
# flattened = flatten_dict(data)
# print(flattened)

# 9.
# D = dict(x={'name': 'Boss', 'job': 'Mgr'},
#          y={'name': 'Suresh', 'job': 'Dev'},
#          z={'name': 'Siva', 'job': 'Dev'})
#
# print(D)


10.
D = {'x': {'name': 'Boss', 'job': 'Mgr'},
     'y': {'name': 'Suresh', 'job': 'Dev'},
     'z': {'name': 'Siva', 'job': 'Dev'}}

removed = D.popitem()
print(D)
print(removed)
