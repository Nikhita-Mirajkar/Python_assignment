#1.
# num = int(input("Please Enter any Positive Integer less than 5 : "))
# if num >= 5 or num <= 0:
#     print("Invalid input. Please enter a positive integer less than 5.")
# else:
#     while num <= 5:
#         print("\nMultiplication Table")
#         i = 1
#         while i <= 10:
#             print(f"{i}  *  {num}  =  {i * num}")
#             i += 1
#         num += 1

#2.
# x = [10, 20, 30, 40, 50]
# i = 0
# total = 0
# while i < len(x):
#     print(x[i])
#     total += x[i]
#     i += 1
# print("Sum= ", total)

#3.
# minimum = 21
# maximum = 30
# if minimum % 2 != 0:
#     minimum += 1
# while minimum <= maximum:
#     print(minimum)
#     minimum += 2

#4.
# lines = []
# print("Enter lines of text (press Enter on a blank line to stop):")
# while True:
#     line = input()
#     if line == "":
#         break
#     lines.append(line.upper())
# for line in lines:
#     print(line)

#5.
# import random
# secret_number = random.randint(0, 10)
# chances = 3
# for i in range(chances):
#     guess = int(input("Enter your guess: "))
#     if guess == secret_number:
#         print("You win!")
#         break
# else:
#     print("You lose")


#6.
# import re
# password = input("Input your password: ")
# if (len(password) < 8):
#     print("Not a Valid Password")
# elif not re.search("[a-z]", password):
#     print("Not a Valid Password")
# elif not re.search("[A-Z]", password):
#     print("Not a Valid Password")
# elif not re.search("[0-9]", password):
#     print("Not a Valid Password")
# elif not re.search("[@#$%^&+=]", password):
#     print("Not a Valid Password")
# else:
#     print("Valid Password")


#7.
# letter = input("Input a letter of the alphabet: ")
# if len(letter) == 1 and letter.isalpha():
#     # Convert to lowercase for comparison
#     if letter.lower() in 'aeiou':
#         print(f"{letter} is a vowel.")
#     else:
#         print(f"{letter} is a consonant.")
# else:
#     print("Invalid input. Please enter a single alphabet letter.")


#8.
# total = 0
# count = 0
# print("Enter numbers (0 to finish):")
# while True:
#     num = int(input())
#     if num == 0:
#         break
#     total += num
#     count += 1
# if count == 0:
#     print("No numbers were entered.")
# else:
#     average = total / count
#     print("Average and Sum of the above numbers are: ", average, float(total))


#9.
# terms = 7
# print("Fibonacci sequence:")
# a, b = 0, 1
# count = 0
# while count < terms:
#     print(a, end=" ")
#     a, b = b, a + b
#     count += 1
# print()


#10.
# x = 987654
# print("Given Number: ", x)
# reversed_num = int(str(x)[::-1])
# print("Reversed Number: ", reversed_num)

#11.
# def digit_sum(n):
#     total = 0
#     while n > 0:
#         total += n % 10
#         n //= 10
#     return total
# print(digit_sum(892))

#12.
# import random
#
# even_count = 0
# odd_count = 0
#
# for _ in range(100):
#     num = random.randint(1, 1000)
#     if num % 2 == 0:
#         even_count += 1
#     else:
#         odd_count += 1
#
# print(f"Out of 100 Random Numbers, {even_count} were even and {odd_count} were odd")


#13.
# import random
#
# for _ in range(3):  # Run 3 times
#     even_count = 0
#     odd_count = 0
#
#     for _ in range(100):
#         num = random.randint(1, 1000)
#         if num % 2 == 0:
#             even_count += 1
#         else:
#             odd_count += 1
#
#     print(f"Out of 100 Random Numbers, {even_count} were even and {odd_count} were Odd")

#14.
# num = int(input("Enter a number: "))
# factorial = 1
# if num < 0:
#     print("Factorial is not defined for negative numbers.")
# elif num == 0 or num == 1:
#     print("Factorial is 1")
# else:
#     i = 1
#     while i <= num:
#         factorial *= i
#         i += 1
#     print(factorial)


#15.
# num1 = int(input("Enter the first number:"))
# num2 = int(input("Enter the second number:"))
# def gcd(a, b):
#     while b != 0:
#         a, b = b, a % b
#     return a
# print(gcd(num1, num2))


#16.
# num = input("Enter a number:")
# total = 0
# for digit in num:
#     total += int(digit)
#
# print(total)


#17.
# num = int(input("Enter a number: "))
# print("Prime factors:")
# factor = 2
#
# while factor <= num:
#     if num % factor == 0:
#         print(factor)
#         num //= factor
#     else:
#         factor += 1


#18.
# x = input("Enter a number: ")
# total_digits = len(x)
# print("Total digits are: ", total_digits)


#19.
# count = 0
# result = []
# for i in range(5):
#     temp_list = []
#     for j in range(10):
#         temp_list.append(0)
#     result.append(temp_list)
#
# print(result)



#20.
data = [2, 3, 12, 5]

for num in data:
    print('*' * num)
