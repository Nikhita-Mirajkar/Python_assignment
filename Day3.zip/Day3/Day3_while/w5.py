'''5. Write a python program to print the following pattern using while loop.
    Expected output:
    *
    * *
    * * *
    * * * *
    '''
x=0
while x