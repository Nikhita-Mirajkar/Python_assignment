'''5. Write a python program to print the following pattern using while loop.
    Expected output:
    *
    * * 
    * * * 
    * * * *'''
# i = 1
# while i <= 4:
#     print('* ' * i)
#     i += 1

'''6. Write a python program to print multiplication table of 24 using while loop.
    Data:
        24
    Expected output:
        24 48 72 96 120 144 168 192 216 240'''
# i = 1
# while i <= 10:
#     print(24 * i, end=' ')
#     i += 1

'''7. Write a python program to print first 10 natural numbers using while loop.
    Data:
        10
    Expected output:
        0 1 2 3 4 5 6 7 8 9 10 '''
# i = 0
# while i <= 10:
#     print(i, end=' ')
#     i += 1

'''8. Write a python program to get the fibonacci series between 0 to 50.
    Data:
        x,y = 0,1
    Expected output:
        1
        1
        2
        3
        5
        8
        13
        21
        34'''
# x, y = 0, 1
# while y < 50:
#     print(y)
#     x, y = y, x + y

'''9. Write a python program to construct the following pattern.
    Expected output:
        1
        22
        333
        4444
        55555
        666666
        7777777
        88888888
        999999999'''

# i = 1
# while i <= 9:
#     print(str(i) * i)
#     i += 1

'''10. Write a python program to add natural number up to sum = 1+2+3+.....+n
    Expected output:
        The sum is  15'''
# n = 5
# total = 0
# i = 1
# while i <= n:
#     total += i
#     i += 1
#
# print("The sum is", total)

'''11. Write a python program to illustrate the working of while loop with else statement.
    Expected output:
        Inside loop
        Inside loop
        Inside loop
        Inside else'''

# i = 1
# while i < 4:
#     print("Inside loop")
#     i += 1
# else:
#     print("Inside else")

'''12. Write a simple python program to illustrate the working of nested while loop using given data.
    Data:
        i = 1
        j = 3
    Expected output:
        1 , 3
        2 , 4
        3 , 5
        4 , 6
        5 , 7'''
# i = 1
# j = 3
# count = 0
#
# while count < 5:
#     print(f"{i} , {j}")
#     i += 1
#     j += 1
#     count += 1

'''13. Write a Python program to print the following output from given data using while loop.
    Data:
        n = 7, c = 0
    Expected output:
        5
        11'''
# n = 7
# c = 0
# result = []
#
# while c < 2:
#     val = n - (2 * (1 - c))  # For c=0 -> 5, c=1 -> 11
#     result.append(val)
#     c += 1
#
# for r in result:
#     print(r)

'''14. Write a python program to exit the loop when x is 3, using break statement in a while loop.
    Data:
        x = 1
    Expected output:
        1
        2
        3'''
# x = 1
# while True:
#     print(x)
#     if x == 3:
#         break
#     x += 1

'''15. Write a python program to continue the next iteration if x is 3.
    Data:
        x = 0
    Expected output:
        1
        2
        4
        5
        6'''
# x = 0
# while x < 6:
#     x += 1
#     if x == 3:
#         continue
#     print(x)

'''16. Write a python program to print a message once the while condition is false.
    Data:
        x = 1
    Expeccted output:
        1
        2
        3
        4
        5
        x is no longer less than 6'''
# x = 1
# while x < 6:
#     print(x)
#     x += 1
# print("x is no longer less than 6")

'''17. Write a python program to illustrate a simple while loop.
    Data:
        Hello Words
    Expected output:
        Hello Words
        Hello Words
        Hello Words'''
# count = 0
# while count < 3:
#     print("Hello Words")
#     count += 1

'''18. Write a python program to use pass statement in a while loop.
    Data:
        x = "jackforjack"
        y = 0
    Expected output:
        Value of y:  11'''
# x = "jackforjack"
# y = 0
#
# while y < len(x):
#     pass  # does nothing, just a placeholder
#     y += 1
#
# print("Value of y: ", y)

'''19. Write a python program to demonstrate while-else loop.
    Data:
        x = 0
    Expected output:
        1
        2
        3
        4
        Good bye'''

# x = 0
#
# while x < 4:
#     x += 1
#     print(x)
# else:
#     print("Good bye")

'''20. Write a Python program to print multiplication table of 5 using while loop.
    Expected output:
        5 * 1 = 5
        5 * 2 = 10
        5 * 3 = 15
        5 * 4 = 20
        5 * 5 = 25
        5 * 6 = 30
        5 * 7 = 35
        5 * 8 = 40
        5 * 9 = 45
        5 * 10 = 50'''

i = 1
while i <= 10:
    print(f"5 * {i} = {5 * i}")
    i += 1
