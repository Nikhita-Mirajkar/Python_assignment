'''2. Write a simple python program to demonstrate a while loop with else block.
    Data:
        x = 10
    Expected output:
        10
        9
        8
        7
        loop is finished'''
x = 10
i=0
while x>6:
    print(x)
    x-=1
else:
    print("loop is finished")