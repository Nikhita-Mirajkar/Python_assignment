'''3. write a python program to print x as long as x is less than 6, using while loop.
    Data:
        x = 1
    Expected output:
        1
        2
        3
        4
        5'''
x=1
while x<=5:
    print(x)
    x+=1