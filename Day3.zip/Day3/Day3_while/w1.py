'''1. Write a python program to pop() elements until the list has elements using while loop.
    Data:
        a = [1,2,3,4,5]
    Expected output:
        5
        4
        3
        2
        1'''
a = [1, 2, 3, 4, 5]
while a:
    popped_element = a.pop()
    print(popped_element)