'''4. Write a python program to check if list still contains any element using while loop and pop().
    Data:
        x = [0,1,2,3,4,5]
    Expected output:
        5
        4
        3
        2
        1
        0'''
x = [0, 1, 2, 3, 4, 5]
while x:
    if x!=0:
        pop_element=x.pop()
        print(pop_element)
