''' 12. Write a Python program to print the count of no. of elements in a list until an
element in a list is a tuple using isinstance() method.
    Data:
        x = [10,20,30,(10,20),40]
    Expected Output: 3 '''
x = [10, 20, 30, (10, 20), 40]
count = 0

for element in x:
    if isinstance(element, tuple):
        break  # Stop counting when a tuple is found
    count += 1

print(count)