''' 13. Write a Python program to access the index of elements in a list.
    Data:
        x = [5, 15, 35, 8, 98]
    Expected Output:
        0 5
        1 15
        2 35
        3 8
        4 98 '''
from operator import indexOf

x = [5, 15, 35, 8, 98]
for index,value in enumerate(x):
    print(index,value)