'''8. Write a Python program to print expected output, range between 2 to 30 and increment the sequence by 3.
    Expected Output:
    2
    5
    8
    11
    14
    17
    20
    23
    26
    29 '''
for i in range(2,30,3):
    print(i)
