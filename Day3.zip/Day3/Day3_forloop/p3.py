''' 3. Write a Python program to print expected output using break statement from the data given below.
    Data:
        country = ["India", "Canada", "Sweden"]
    Expected Output:
    India
    Canada '''
country = ["India", "Canada", "Sweden"]
for i in country:
    if i=="Sweden":
        break
    print(i)