''' 15. Write a Python program to create a list of empty dictionaries.
    Data:
        n = 5
    Expected Output:
        [{}, {}, {}, {}, {}] '''
n = 5
empty_dictionaries_list = [{} for _ in range(n)]
print(empty_dictionaries_list)