#5. Write a Python program to having an empty for loop like this,
# would raise an error without the pass statement.

for i in range(4):
    pass
print('loop executed')
