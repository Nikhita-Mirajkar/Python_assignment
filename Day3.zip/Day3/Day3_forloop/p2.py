''' 2. Write a Python program to print expected output from the data given below.
    Data:
         string = "banana"
    Expected Output:
    b
    a
    n
    a
    n
    a '''

string = "banana"
for i in string:
    print(i)