''' 11. Write a Python program to convert list of tuples into dictionary using setdefault() method.
    Data:
        l = [("x", 1), ("x", 2), ("x", 3), ("y", 1), ("y", 2), ("z", 1)]
    Expected Output:
        {'x': [1, 2, 3], 'y': [1, 2], 'z': [1]} '''
data= [("x", 1), ("x", 2), ("x", 3), ("y", 1), ("y", 2), ("z", 1)]
result={}
for key,value in data:
    result.setdefault(key,[]).append(value)
print(result)