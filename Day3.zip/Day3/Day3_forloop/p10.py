''' 10. Write a Python program to print each adjective for every fruits using nested for loop from the data given below.
    Data:
        adjective = ["red", "big", "tasty"]
        fruits = ["apple", "banana", "cherry"]
    Expected Output:
        red apple
        red banana
        red cherry
        big apple
        big banana
        big cherry
        tasty apple
        tasty banana
        tasty cherry '''

adjective = ["red", "big", "tasty"]
fruits = ["apple", "banana", "cherry"]
for i in adjective:
    for j in fruits:
        print(i,j)