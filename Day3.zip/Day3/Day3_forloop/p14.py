''' 14. Write a Python program to create multiple lists.
    Expected output:
        {'1': [], '2': [], '3': [], '4': [], '5': [], '6': [], '7': [], '8': [], '9': [], '10': []} '''
multiple_lists = {str(i): [] for i in range(1, 11)}
print(multiple_lists)