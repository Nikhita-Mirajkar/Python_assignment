''' 7. Write a Python program to print expected output by passing range parameters as (2, 6).
    Expected Output:
    2
    3
    4
    5 '''
for i in range(2,6):
    print(i)