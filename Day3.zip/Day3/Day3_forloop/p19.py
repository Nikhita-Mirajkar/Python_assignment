''' 19. Write a Python program to print expected output using enumerate() from the data given below.
    Data:
        x = ["suresh", "boss", "siva", "bala", "sai", "balu", "karthi"]
    Expected Output:
        President 1: suresh
        President 2: boss
        President 3: siva
        President 4: bala
        President 5: sai
        President 6: balu
        President 7: karthi '''
x = ["suresh", "boss", "siva", "bala", "sai", "balu", "karthi"]
for index,name in enumerate(x,start=1):
    if index==7:
        print(f'President {index}: {name}')
    else:
        print(f'President {index}: {name}')