''' 17. Write a Python program print all elements of the list using for loop and range().
    Data:
        name = ['boss', 'sai', 'bala']
    Expected Output:
        boss
        sai
        bala '''
name = ['boss', 'sai', 'bala']
for i in range(len(name)):
    print(name[i])