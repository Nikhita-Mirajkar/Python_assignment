'''
 1. Write a Python program to print expected output from the data given below.
    Data:
         country = ["India", "Canada", "Sweden"]
    Expected Output:
    India
    Canada
    Sweden
     '''
country = ["India", "Canada", "Sweden"]
for i in country:
    print(i)
