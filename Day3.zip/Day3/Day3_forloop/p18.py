# 18. Write a Python program to print without newline or space.
print("Hello", "World", "!", sep="", end="")
