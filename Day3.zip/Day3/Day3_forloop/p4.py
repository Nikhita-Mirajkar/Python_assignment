''' 4. Write a Python program to print expected output using continue statement from the data given below.
    Data:
        country = ["India", "Canada", "Sweden"]
    Expected Output:
    India
    Sweden '''
country = ["India", "Canada", "Sweden"]
for i in country:
    if i=="Canada":
        continue
    print(i)