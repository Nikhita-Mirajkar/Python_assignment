''' 20. Write a Python program to print expected output using enumerate() from the data given below.
    Data:
        name = ["suresh", "boss", "siva", "bala"]
        ratios = [0.2, 0.3, 0.1, 0.4]
    Expected Output:
        20.0% suresh
        30.0% boss
        50.0% siva
        40.0% bala '''

name = ["suresh", "boss", "siva", "bala"]
ratios = [0.2, 0.3, 0.1, 0.4]
for i,(n,r) in enumerate(zip(name,ratios)):
    if i==2:
        print(f"{(ratios[0]+ratios[1]+ratios[2])*100:.1f}% {n}")
    else:
        print(f"{r*100:.1f}% {n}")