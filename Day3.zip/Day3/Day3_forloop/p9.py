''' 9. Write a Python program to print all numbers from 0 to 5, and print a message when the loop has ended.
    Expected Output:
    0
    1
    2
    3
    4
    5
    Finally finished! '''
for i in range(6):
    print(i)
print("Finally finished")