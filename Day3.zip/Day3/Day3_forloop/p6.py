''' 6. Write a Python program to print expected output using range in for loop.
    Expected Output:
    0
    1
    2
    3
    4
    5 '''
for i in range(6):
    print(i)