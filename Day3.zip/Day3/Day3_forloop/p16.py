''' 16. Write a Python program to iterate over two lists simultaneously.
    Data:
        x = [1, 2, 3]
        name = ['boss', 'sai', 'bala']
    Expected Output:
        1 boss
        2 sai
        3 bala '''
x=[1,2,3]
name=['boss','sai','bala']
for i,n in zip(x,name):
    print(i,n)