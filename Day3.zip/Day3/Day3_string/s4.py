'''4. Write a Python program to remove the values of the odd index from a given string.
    Data:
        'abcdef'
        'python'
    Expected Output:
        ace
        pto'''
s1=input('Enter the string: ')
s2=''
for i in range(len(s1)):
    if i%2==0:
        s2=s2+s1[i]
print(s2)