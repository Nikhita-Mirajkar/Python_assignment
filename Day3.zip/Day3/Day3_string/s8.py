'''8. Write a Python function to insert the second string in the middle of a first string.
    Data:
        ('[[]]', 'Python')
        ('{{}}', 'PHP')
    Expected Output:
        [[Python]]
        {{PHP}}'''
def insert_string_middle(str1,str2):
    half_len=(len(str1)//2)
    return str1[:half_len]+str2+str1[half_len:]
print(insert_string_middle('[[]]','Python'))
print(insert_string_middle('{{}}',"PHP"))