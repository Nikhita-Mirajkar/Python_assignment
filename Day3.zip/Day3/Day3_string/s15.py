'''15. Write a Python program to check whether a string starts with specified character.
    Data:
        aidinasaur.com
    Expected Output:
        True
        '''
s='aidinasaur.com'
print(s.startswith('aid'))