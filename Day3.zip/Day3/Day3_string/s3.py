'''3. Write a Python program to interchange the first and last character of a given string.
    Data:
        'abcd'
        '12345'
    Expected Output:
        dbca
        52341
        '''
s1='abcd'
s2='12345'
def interchange_char(a):
    a1=a.replace(a[0],a[-1])
    a2=a.replace(a[-1],a[0])
    print( a1[:2]+a2[2:] )
interchange_char(s2)
