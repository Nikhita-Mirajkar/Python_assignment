'''17. Write a Python program to reverse a string.
    Data:
        "abcdef"
        "Python Exercises."
    Expected Output:
        fedcba
        .sesicrexE nohtyP
'''
s=input('Enter the string: ')
print(s[::-1])