'''6. Write a Python program that accepts a comma separated sequence of words as
 input and print only the unique strings in sorted.
    Data:
        Words : red, white, black, red, green, black
    Expected Output:
        black, green, red, white,red'''
words=['red', 'white', 'black', 'red', 'green', 'black']
w=set(words)
#print(w)
s=sorted(w)
print(s)
