'''2. Write a Python program to remove the character of the nth index from a given string.
    Data:
        "Python"
    Expected Output:
        ython
        Pyton
        Pytho
'''
a="Python"
n=int(input('Enter the index:'))
def remove_nth_char(s,n):
    if n<0 or n>=len(a):
        print('Index not found')
    print(s[:n]+s[n+1:])
remove_nth_char(a,n)
