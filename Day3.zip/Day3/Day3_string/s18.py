'''18. Write a Python program to lowercase first n characters in a string.
    Data:
        "AIDINASAUR.COM"
    Expected Output:
        aidiNASAUR.COM
        '''
s="AIDINASAUR.COM"
n=int(input('Enter the index size: '))
s1=s.lower()