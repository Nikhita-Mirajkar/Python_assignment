'''5. Write a Python program to get input from the user and print the input back in uppercase.
    Data:
        Whats your favourite language: Tamil
    Expected Output:
        My favourite language is  TAMIL
        My favourite language is  tamil'''
s=input('What is your favourite language: ')
s2=s.upper()
print('My favourite language is: ',s2)