'''7. Write a Python function to create the HTML string with tags around the string.
    Data:
        ('i', 'Python')
        ('b', 'Python Tutorial')
    Expected Output:
        <i>Python</i>
        <b>Python Tutorial </b>'''
def add_tags(tag,name):
    formatted_string=f'<{tag}>{name}</{tag}>'
    print(formatted_string)
add_tags("i","Python")
add_tags('b','Python Tutorial')