'''16. Write a Python program to count the number of occurrences of a substring in a string.
    Data:
        "Word to publish Word docs as web pages"
        count = "word"
    Expected Output:
        2'''
s="Word to publish Word docs as web pages"
print(s.count('Word'))