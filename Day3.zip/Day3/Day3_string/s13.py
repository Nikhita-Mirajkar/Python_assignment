'''13. Write a Python program to sort a string lexicographically.
    Data:
        aidinasaur
    Expected Output:
        ['a', 'a', 'a', 'd', 'i', 'i', 'n', 'r', 's', 'u']'''
s='aidinasaur'
a=sorted(s)
print(a)