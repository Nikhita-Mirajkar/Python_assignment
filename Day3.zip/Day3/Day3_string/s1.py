'''1. Write a Python program to calculate the length of a given string.
    Data:
        "Baskar"
    Expected Output:
        6'''

x="Baskar"
print(len(x))