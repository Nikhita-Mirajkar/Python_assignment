'''1. Write a Python program to find the first repeated character in a given string.
    Data:
        "abcdabcd"
        "abcd"
    Expected Output:
        a
        None'''

# def first_repeated_char(s):
#     seen = []
#     for char in s:
#         if char in seen:
#             return char
#         seen.append(char)
#     return None

# print(first_repeated_char("abcdabcd"))
# print(first_repeated_char("abcd"))


'''2. Write a Python program to find the first repeated character of a given string where the index of first occurrence is smallest.
    Data:
        "abcabc"
        "abcb"
        "abcc"
        "abcxxy"
        "abc"
    Expected Output:
        ('a', 0) 
        ('b', 1)
        ('c', 2)
        ('x', 3)
        None'''

# def first_repeated_with_smallest_index(s):
#     seen = {}
#     for i, char in enumerate(s):
#         if char in seen:
#             return (char, seen[char])
#         else:
#             seen[char] = i
#     return None
#
# print(first_repeated_with_smallest_index("abcabc"))  # ('a', 0)
# print(first_repeated_with_smallest_index("abcb"))    # ('b', 1)
# print(first_repeated_with_smallest_index("abcc"))    # ('c', 2)
# print(first_repeated_with_smallest_index("abcxxy"))  # ('x', 3)
# print(first_repeated_with_smallest_index("abc"))     # None


'''4. Write a Python program to find the maximum occurring character in a given string.
    Data:
        "Python: Get file creation and modification date/times"
        "abcdefghijkb"
    Expected Output:
        t
        b'''

# def max_occurring_char(s):
#     freq = {}
#     for char in s:
#         freq[char] = freq.get(char, 0) + 1
#     max_char = max(freq, key=freq.get)
#     return max_char
#
# print(max_occurring_char("Python: Get file creation and modification date/times"))
# print(max_occurring_char("abcdefghijkb"))

'''5. Write a Python program to capitalize first and last letters of each word of a given string.
    Data:
        "python exercises practice solution"
        "aidinasaur"
    Expected Output:
        PythoN ExerciseS PracticE SolutioN
        AidinasauR'''
# def capitalize_first_last(s):
#     words = s.split()
#     result = []
#     for word in words:
#         if len(word) == 1:
#             result.append(word.upper())
#         else:
#             result.append(word[0].upper() + word[1:-1] + word[-1].upper())
#     return ' '.join(result)
#
# print(capitalize_first_last("python exercises practice solution"))
# print(capitalize_first_last("aidinasaur"))

'''6. Write a Python program to compute sum of digits of a given string.
    Data:
        "123abcd45"
        "abcd1234"
    Expected Output:
        15
        10'''

# def sum_of_digits(s):
#     total = 0
#     for char in s:
#         if char.isdigit():
#             total += int(char)
#     return total
#
# print(sum_of_digits("123abcd45"))
# print(sum_of_digits("abcd1234"))

'''7. Write a Python program to find maximum length of consecutive 0's in a given binary string.
    Data:
        Original string:
        111000010000110
        111000111
    Expected Output:
        Maximum length of consecutive 0’s:
        4
        Maximum length of consecutive 0’s:
        3'''
# def max_consecutive_zeros(s):
#     max_count = 0
#     count = 0
#     for char in s:
#         if char == '0':
#             count += 1
#             if count > max_count:
#                 max_count = count
#         else:
#             count = 0
#     return max_count
#
# print("Maximum length of consecutive 0’s:")
# print(max_consecutive_zeros("111000010000110"))
#
# print("Maximum length of consecutive 0’s:")
# print(max_consecutive_zeros("111000111"))

'''8. Write a Python program to find all the common characters in lexicographical order from two given lower case strings. 
   If there are no common letters print "No common characters".
    Data:
        Two strings: Python : PHP
        Two strings: Java : PHP
    Expected Output:
        P
        No common characters.'''

# def common_chars(s1, s2):
#     common = sorted(set(s1) & set(s2))
#     if common:
#         print(''.join(common))
#     else:
#         print("No common characters.")
#
# common_chars("python", "php")
# common_chars("java", "php")

'''9. Write a Python program to make two given strings (lower case, may or may not be of the same length) 
   anagrams removing any characters from any of the strings.
    Data:
        "marvelboss gaming"
        "marvelboss timepss"
    Expected Output:
        9'''

'''10. Write a Python program to remove all consecutive duplicates of a given string.
    Data:
        str1 = 'xxxxxyyyyy'
    Expected Output:
        After removing consecutive duplicates: xxxxxyyyyy
        xy'''
# def remove_consecutive_duplicates(s):
#     if not s:
#         return ""
#     result = s[0]
#     for char in s[1:]:
#         if char != result[-1]:
#             result += char
#     return result
#
# str1 = 'xxxxxyyyyy'
# print("After removing consecutive duplicates:")
# print(str1)
# print(remove_consecutive_duplicates(str1))


'''11. Write a Python program to find the longest common sub-string from two given strings.
    Data:
        Original Substrings:
        abcdefgh
        xswerabcdwd
    Expected Output:
        Common longest sub string:
        abcd'''

# def longest_common_substring(s1, s2):
#     m = len(s1)
#     n = len(s2)
#     max_len = 0
#     ending_index = 0
#
#     # Create a 2D list to store lengths of longest common suffixes
#     length = [[0] * (n + 1) for _ in range(m + 1)]
#
#     for i in range(1, m + 1):
#         for j in range(1, n + 1):
#             if s1[i - 1] == s2[j - 1]:
#                 length[i][j] = length[i - 1][j - 1] + 1
#                 if length[i][j] > max_len:
#                     max_len = length[i][j]
#                     ending_index = i
#             else:
#                 length[i][j] = 0
#
#     return s1[ending_index - max_len: ending_index]
#
# s1 = "abcdefgh"
# s2 = "xswerabcdwd"

# print("Common longest sub string:")
# print(longest_common_substring(s1, s2))


'''12. Write a Python program to move all spaces to the front of a given string in single traversal.
    Data:
        Original String:
        Python Exercises
    Expected Output:
        After moving all spaces to the front:
        PythonExercises '''
# def move_spaces_front(s):
#     spaces = ""
#     chars = ""
#     for char in s:
#         if char == ' ':
#             spaces += char
#         else:
#             chars += char
#     return spaces + chars
#
# s = "Python Exercises"
# print("After moving all spaces to the front:")
# print(move_spaces_front(s))

'''13. Write a Python code to remove all characters except a specified character in a given string. 
    Data:
        Original string
        "Python Exercises"
        "google"
        "exercises"
    Expected Output:
        Remove all characters except P in the said string:
        P
        Remove all characters except g in the said string:
        gg
        Remove all characters except e in the said string:
        eee'''
# def keep_only_char(s, ch):
#     count = s.count(ch)
#     return ch * count
#
# print("Remove all characters except P in the said string:")
# print(keep_only_char("Python Exercises", "P"))
#
# print("Remove all characters except g in the said string:")
# print(keep_only_char("google", "g"))
#
# print("Remove all characters except e in the said string:")
# print(keep_only_char("exercises", "e"))


'''14. Write a Python program to count Uppercase, Lowercase, special character and numeric values in a given string.
    Data:
        Original Substrings: @Aidinasaur.Com
    Expected Output:
        Upper case characters:  2
        Lower case characters:  11
        Number case:  0
        Special case characters:  2'''


# def count_char_types(s):
#     uppercase = 0
#     lowercase = 0
#     numeric = 0
#     special = 0
#
#     for char in s:
#         if char.isupper():
#             uppercase += 1
#         elif char.islower():
#             lowercase += 1
#         elif char.isdigit():
#             numeric += 1
#         else:
#             special += 1
#
#     print("Upper case characters: ", uppercase)
#     print("Lower case characters: ", lowercase)
#     print("Number case: ", numeric)
#     print("Special case characters: ", special)
#
#
# count_char_types("@Aidinasaur.Com")

'''15. Write a Python program to find the minimum window in a given string which will contain all
    the characters of another given string.
    Data:
        Original Strings:
        PRWSOERIUSFK 
        OSU
    Expected Output:
        Minimum window:
        OERIUS'''

'''16. Write a Python program to find smallest window that contains all characters of a given string.
    Data:
        Original Strings:
        asdaewsqgtwwsa
    Expected Output:
        Smallest window that contains all characters of the said string:
        daewsqgt'''
# def smallest_window_all_chars(s):
#     unique_chars = set(s)
#     min_len = len(s) + 1
#     min_window = ""
#
#     for i in range(len(s)):
#         for j in range(i + len(unique_chars), len(s) + 1):
#             window = s[i:j]
#             if all(window.count(c) >= 1 for c in unique_chars):
#                 if len(window) < min_len:
#                     min_len = len(window)
#                     min_window = window
#                 break  # no need to check longer windows starting at i
#     return min_window
#
# s = "asdaewsqgtwwsa"
# print("Smallest window that contains all characters of the said string:")
# print(smallest_window_all_chars(s))

'''17. Write a Python program to find smallest and largest word in a given string.
    Data:
        Original Strings:
        Write a Java program to sort an array of given integers using Quick sort Algorithm.
    Expected Output:
        Smallest word: a
        Largest word: Algorithm.'''

# def smallest_largest_word(s):
#     words = s.split()
#     smallest = min(words, key=len)
#     largest = max(words, key=len)
#     print("Smallest word:", smallest)
#     print("Largest word:", largest)
#
# s = "Write a Java program to sort an array of given integers using Quick sort Algorithm."
# smallest_largest_word(s)


'''18. Write a Python program to find the index of a given string at which a given substring starts. If the substring is 
    not found in the given string return 'Not found
    Data:
        "Ex"
        "yt"
        "PY"
    Expected Output:
        7
        1
        Not found'''
# def find_substring_index(s, sub):
#     index = s.find(sub)
#     if index == -1:
#         return "Not found"
#     else:
#         return index
#
# s = "Python Exercises"
# substrings = ["Ex", "yt", "PY"]
#
# for sub in substrings:
#     print(find_substring_index(s, sub))

'''19. Write a Python program to swap cases of a given string.
    Data:
        "Python Exercises"
        "Java"
        "NumPy"
    Expected Output:
        pYTHON eXERCISES
        jAVA
        nUMpY'''
# def swap_cases(s):
#     return s.swapcase()
#
# strings = ["Python Exercises", "Java", "NumPy"]
#
# for s in strings:
#     print(swap_cases(s))


'''20. Write a Python program to convert a given Bytearray to Hexadecimal string.
    Data:
        Original Bytearray :
        [111, 12, 45, 67, 109]
    Expected Output:
        Hexadecimal string:
        6f0c2d436d'''

byte_arr = bytearray([111, 12, 45, 67, 109])
hex_str = byte_arr.hex()
print("Hexadecimal string:")
print(hex_str)
