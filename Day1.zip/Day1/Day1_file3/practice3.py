# Write a program to hours to minutes , user should able to give hours as input

# your Answer
a=int(input('enter the number of hours:'))
b=a*60
print(a,'hours equals to',b,'minutes')



