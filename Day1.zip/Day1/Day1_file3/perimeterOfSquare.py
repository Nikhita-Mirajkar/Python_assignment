# Write a program to calculate perimeter of square

# your Answer
a=int(input('Enter the value for side:'))
p=4*a
print('Perimeter of square is:',p)
