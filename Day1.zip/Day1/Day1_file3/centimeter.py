# Write a program to convert centimeter to meter , user shoulb be able to give centimeter as input

# your Answer
x=int(input('Enter the centerimeter :'))
z=x*0.01
print('The meter for above equivalent centimeter is',z)
