# Write a program to area of traingle

# your Answer
b=int(input('Enter base of triangle:'))
h=int(input('Enter height of triangle:'))
a=(1/2)*b*h
print('Area of triangle is:',a)
