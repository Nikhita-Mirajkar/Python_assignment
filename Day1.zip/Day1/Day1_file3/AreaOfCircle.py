# Write a program to calculate area of circle

# your Answer
r=int(input('Enter  the radius:'))
a=3.14*r*r
print('Area of circle:',a)