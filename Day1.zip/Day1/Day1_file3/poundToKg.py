# Write a program to convert pounds to Kilogram , user shoulb be able to give pounds as input

# your Answer


x=int(input('Enter the pounds: '))
y=x*0.454
print('The equivalent kilograms for ponds is ',y)