# Write a program to convert miles to Kilometer , user shoulb be able to give miles as input

# your Answer
x=int(input('Enter the miles: '))
y=x*1.6
print('The equivalent kilometer for miles is ',int(y))