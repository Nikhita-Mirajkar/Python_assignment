# Write a program to calculate simple interest # all input shoulb be given by the user

# your Answer
a=int(input('Enter principle amt:'))
b=int(input('enter no of years:'))
c=int(input('enter rate of interest:'))
si=(a*b*c)/100
print("the simple interest is:",si)