# Write a program to calculate area of square

# your Answer
s=int(input('Enter the value for side:'))
a=s*s
print('Area of square is:',a)