# write a program to add two  integers 10 , 20
a=10
b=20
c=a+b
print('Addition of two integers:',c)
