# Write a program to find whether given number is odd or even

a=int(input('Enter a number:'))
if a%2==0:
    print(a ,'is even')
else:
    print(a, 'is odd')