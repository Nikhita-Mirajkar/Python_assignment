# Write a program to convert Celcius to Fariehiet , fariienhiet=1.8*celcius+32

c=int(input('Enter the celcius: '))
f=1.8*c+32
print('The equivalent farenheit for celcius is ',f)