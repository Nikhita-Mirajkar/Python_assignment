# Write a program to swap the two numbers , where a=2 ,b=4 the program should print a= 4 ,b=2
a=2
b=4
print('a=',b)
print('b=',a)