# Write a program to check whether the person can vote or not
age=int(input('Enter the age:'))
if age>=18:
    print('Person can vote')
else:
    print('Person cannot vote')
