# Write a program to find the type of a, b ,c where a=2, b=2.8,c="John"
a = 2
b = 2.8
c = "John"
print(type(a))
print(type(b))
print(type(c))
