# Write a program to swap the two numbers , using 3 variables
x = 100
y = 200
temp = x
x = y
y = temp

print("After swapping (using temp):", "x =", x, "y =", y)