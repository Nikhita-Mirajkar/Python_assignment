# 1 . Question | print - India is number 1 team and has won 2012 worldcup and it rank 1 and the captain name is kohli
team = "India"
worldcup = 2012
captain = "kohli"
rank = 1

print(team,'is number 1 team and has won',worldcup,'worldcup and it rank',rank,'and the captain name is',captain)

# 2 . Question |print the datatype of the x,y,z

x = 56
y = 56.78
z = "python"

# your Answer
print(type(x))
print(type(y))
print(type(z))

# 3 . Question | write a program to print 10.0 using typecasting

a = 10

# Your Answer
print(float(a))

# 4 . Question | write a program to print 12 using typecasting

a = 12.56

# Your Answer
print(int(a))

# 5 . write a program print 30 by using typecasting concept

a = "10"
b = "20"

# Your Answer
print(int(a)+int(b))
