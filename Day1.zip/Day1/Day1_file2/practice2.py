# 1 .Question | Write a program to print 15,5,2 and 0 ,use the approriate operator

a = 10
b = 5

# Your Answer
print(a+b)
print(a-b)
print(a//b)
print(a%b)

# 2 .Question | write a code to print 9 , use the approriate operator
a = 3
b = 2

# Your Answer
print(a*b+a)

# 4 .Question | # write a code to print 2 , 2.25 and 1 , use the approriate operator

x = 9
y = 4

# Your Answer
c=x//y
print(int(c))
d=x/y
print(d)
e=x%y
print(e)

# 5 .Question |  # write a code print True ,use the approriate operator

a = 10
b = 5

# Your Answer
print(a>b)

# 5 .Question | # # write a code print Fale

a = 15
b = 15

# Your Answer

print(a!=b)

# 6 .Question | # # write a code print True

a = 24
b = 24

# Your Answer
print(a==b)

# 7 .Question | # # write a code print True

a = "python"
b = "python"

# Your Answer
print(a==b)


# 8 .Question | #  write a code print false using and operator

a = 10
b = 20

# Your Answer
print(a!=0 and b==0)

# 9 .Question | #  write a code print True using or operator

a = 20
b = 10

# Your Answer
print(a!=0 or b==0)

# 10 .Question | #  write a code print True using Not operator

a = 20
b = 10

# Your Answer
print(a!=0 )

