a=int(input('Enter a number:'))
if a%2==0:
    print(a ,'is even')
else:
    print(a, 'is odd')