year = 2020

if (year % 400 == 0) and (year % 100 == 0):
    print("it is a leap year")

elif (year % 4 ==0) and (year % 100 != 0):
    print("it is a leap year")

else:
    print("{0} is not a leap year")