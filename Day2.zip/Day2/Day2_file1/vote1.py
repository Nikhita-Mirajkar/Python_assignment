# Write a program to print "You can Vote" or "You Cannot Vote
age=int(input('Enter your age:'))
if age>=18:
    print('You can vote')
else:
    print('You cannot vote')
