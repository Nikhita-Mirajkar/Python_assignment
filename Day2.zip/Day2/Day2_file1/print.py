#Write a program to print "Super" if the sum of number is "less" than 1000 and "great" if the sum of number is greater than 1000

a=int(input('Enter the number1:'))
b=int(input('Enter the number2:'))
c=a+b
if c<1000:
    print('Super')
else:
    print('great')