#Read Five marks tamil,english,maths,science and social and if all marks are greater than 35 ,
# print pass else print fail

s1=int(input('Enter tamil marks:'))
s2=int(input('Enter english  marks:'))
s3=int(input('Enter maths marks:'))
s4=int(input('Enter science marks:'))
s5=int(input('Enter social marks:'))

if s1>=35:
    if s2 >= 35:
        if s3 >= 35:
            if s4 >= 35:
                if s5 >= 35:
                    print('Pass')
                else:
                    print('fail')
            else:
                print('fail')
        else:
            print('fail')
    else:
        print('fail')
else:
    print('fail')