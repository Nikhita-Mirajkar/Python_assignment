# Write a function to convert centimeter to meter , user should be able to give centimeter as input
# your Answer

def cmToMeter():
    cm=int(input('Enter the centimeter :'))
    m=cm*0.01
    print('The meter for above equivalent centimeter is',m)
cmToMeter()

