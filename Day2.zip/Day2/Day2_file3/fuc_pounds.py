# Write a function to convert pounds to Kilogram , user shoulb be able to give pounds as input
# your Answer
def pounds():
    p = int(input('Enter the pounds: '))
    kg = p * 0.454
    print('The equivalent kilograms for pounds is ', kg)
pounds()