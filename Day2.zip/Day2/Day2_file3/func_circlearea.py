# Write a function to calculate area of circle
# your Answer


def area_of_circle():
    r = int(input('Enter  the radius:'))
    a = 3.14 * r * r
    print('Area of circle:', a)
area_of_circle()