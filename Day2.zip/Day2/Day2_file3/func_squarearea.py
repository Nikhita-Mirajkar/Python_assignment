# Write a fucntion to calculate area of square
# your Answer
def area():
    a = int(input('Enter the value for side:'))
    p = 4 * a
    print('Perimeter of square is:', p)
area()