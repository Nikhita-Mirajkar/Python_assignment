# Write a function to convert miles to Kilometer , user should be able to give miles as input

def kilo_to_meter():
    m = int(input('Enter the miles: '))
    km = m * 1.6
    print('The equivalent kilometer for miles is ', int(km))
kilo_to_meter()