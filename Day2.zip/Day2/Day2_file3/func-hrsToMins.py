# Write a function to hours to minutes , user should be able to give hours as input

# your Answer

def hrstominscalc(x):
    y = x*60
    print(x,"hours equals to",y,"minutes")
hrstominscalc(2)