# Write a function to calculate circumference of circle
# your Answer
def circumference():
    r = int(input('Enter  the radius:'))
    c = 2 * 3.14 * r
    print('circumference of circle:', c)
circumference()